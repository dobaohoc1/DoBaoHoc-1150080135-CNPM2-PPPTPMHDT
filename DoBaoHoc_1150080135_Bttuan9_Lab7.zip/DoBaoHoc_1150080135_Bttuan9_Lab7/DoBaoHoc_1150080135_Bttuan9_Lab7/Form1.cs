using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DoBaoHoc_1150080135_Bttuan9_Lab7
{
    public partial class Form1 : Form
    {
        // Kết nối
        private SqlConnection sqlCon = null;
        private string strCon = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Administrator\Downloads\DoBaoHoc_1150080135_Bttuan9_Lab7\DoBaoHoc_1150080135_Bttuan9_Lab7\Database1.mdf;Integrated Security=True";

        // Các biến dùng cho thao tác dữ liệu
        private SqlDataAdapter adapter = null;
        private DataSet ds = null;
        private string tableName = "NhaXuatBan";

        public Form1()
        {
            InitializeComponent();

            // Gắn sự kiện
            this.Load += Form1_Load;
            this.btnHienThi.Click += btnHienThi_Click;
            this.dgvDanhSach.SelectionChanged += dgvDanhSach_SelectionChanged;
            this.btnThemDL.Click += btnThemDL_Click;
            this.btnSua.Click += btnSua_Click;
            this.btnXoa.Click += btnXoa_Click;
        }

        // Mở kết nối
        private void MoKetNoi()
        {
            try
            {
                if (sqlCon == null)
                {
                    sqlCon = new SqlConnection(strCon);
                }
                if (sqlCon.State == ConnectionState.Closed)
                {
                    sqlCon.Open();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi mở kết nối:\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Đóng kết nối
        private void DongKetNoi()
        {
            try
            {
                if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                {
                    sqlCon.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi đóng kết nối:\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Xử lý nút hiển thị
        private void btnHienThi_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();
                string sql = $"SELECT * FROM {tableName}";
                SqlDataAdapter tmpAdapter = new SqlDataAdapter(sql, sqlCon);
                DataSet tmpDs = new DataSet();
                tmpAdapter.Fill(tmpDs, "tbl" + tableName);
                if (tmpDs.Tables.Count > 0)
                {
                    dgvDanhSach.DataSource = tmpDs.Tables[0];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu:\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DongKetNoi();
            }
        }

        // Xóa dữ liệu trên form
        private void XoaDuLieuForm()
        {
            txtMaXB.Text = string.Empty;
            txtTenXB.Text = string.Empty;
            txtDiaChi.Text = string.Empty;
        }

        // Hiển thị dữ liệu
        private void hienThiDuLieu()
        {
            try
            {
                MoKetNoi();
                string query = $"SELECT * FROM {tableName}";
                adapter = new SqlDataAdapter(query, sqlCon);
                SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
                ds = new DataSet();
                adapter.Fill(ds, "tbl" + tableName);
                if (ds.Tables.Count > 0)
                {
                    dgvDanhSach.DataSource = ds.Tables["tbl" + tableName];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi hiển thị dữ liệu:\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DongKetNoi();
            }
        }

        // Tạo bảng nếu chưa tồn tại
        private void EnsureTableExists()
        {
            try
            {
                MoKetNoi();
                string checkSql = $"IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[{tableName}]') AND type in (N'U')) BEGIN CREATE TABLE [dbo].[{tableName}] (XB NVARCHAR(50) PRIMARY KEY, TenXB NVARCHAR(200) NULL, DiaChi NVARCHAR(300) NULL) END";
                using (SqlCommand cmd = new SqlCommand(checkSql, sqlCon))
                {
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tạo kiểm tra bảng:\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DongKetNoi();
            }
        }

        private void dgvDanhSach_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvDanhSach.CurrentRow == null) return;
            try
            {
                var row = (dgvDanhSach.CurrentRow.DataBoundItem as DataRowView)?.Row;
                if (row != null)
                {
                    if (row.Table.Columns.Contains("XB")) txtMaXB.Text = row["XB"].ToString();
                    else if (row.Table.Columns.Contains("MaNXB")) txtMaXB.Text = row["MaNXB"].ToString();
                    if (row.Table.Columns.Contains("TenXB")) txtTenXB.Text = row["TenXB"].ToString();
                    if (row.Table.Columns.Contains("DiaChi")) txtDiaChi.Text = row["DiaChi"].ToString();
                }
            }
            catch {{ }}
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaXB.Text)) { MessageBox.Show("Mã NXB không được để trống."); return; }
            try
            {
                MoKetNoi();
                string updateSql = $"UPDATE {tableName} SET TenXB=@TenXB, DiaChi=@DiaChi WHERE XB=@XB";
                using (SqlCommand cmd = new SqlCommand(updateSql, sqlCon))
                {
                    cmd.Parameters.AddWithValue("@XB", txtMaXB.Text.Trim());
                    cmd.Parameters.AddWithValue("@TenXB", txtTenXB.Text.Trim());
                    cmd.Parameters.AddWithValue("@DiaChi", txtDiaChi.Text.Trim());
                    int affected = cmd.ExecuteNonQuery();
                    if (affected > 0) MessageBox.Show("Cập nhật thành công."); else MessageBox.Show("Không tìm thấy bản ghi để cập nhật.");
                }
                hienThiDuLieu();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi cập nhật:\n" + ex.Message);
            }
            finally { DongKetNoi(); }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaXB.Text)) { MessageBox.Show("Chọn Mã NXB để xóa."); return; }
            if (MessageBox.Show("Bạn có chắc muốn xóa bản ghi này?", "Xác nhận", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            try
            {
                MoKetNoi();
                string delSql = $"DELETE FROM {tableName} WHERE XB=@XB";
                using (SqlCommand cmd = new SqlCommand(delSql, sqlCon))
                {
                    cmd.Parameters.AddWithValue("@XB", txtMaXB.Text.Trim());
                    int affected = cmd.ExecuteNonQuery();
                    if (affected > 0) MessageBox.Show("Xóa thành công."); else MessageBox.Show("Không tìm thấy bản ghi để xóa.");
                }
                hienThiDuLieu();
                XoaDuLieuForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi xóa:\n" + ex.Message);
            }
            finally { DongKetNoi(); }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            EnsureTableExists();
            hienThiDuLieu();
            XoaDuLieuForm();
            try
            {
                if (split != null)
                {
                    int clientW = this.ClientSize.Width;
                    int desiredMin1 = 250;
                    int desiredMin2 = 300;
                    if (desiredMin1 + desiredMin2 > clientW)
                    {
                        desiredMin2 = Math.Max(50, clientW - desiredMin1);
                    }
                    split.Panel1MinSize = desiredMin1;
                    split.Panel2MinSize = desiredMin2;

                    int max = clientW - split.Panel2MinSize;
                    int desired = (int)(clientW * 0.45);
                    if (desired < split.Panel1MinSize) desired = split.Panel1MinSize;
                    if (desired > max) desired = max;
                    if (desired >= split.Panel1MinSize && desired <= max)
                    {
                        split.SplitterDistance = desired;
                    }
                    else
                    {
                        split.SplitterDistance = Math.Min(Math.Max(split.Panel1MinSize, 100), Math.Max(100, max));
                    }
                }
            }
            catch {{ }}
        }

        private void btnThemDL_Click(object sender, EventArgs e)
        {
            if (ds == null || adapter == null)
            {
                MessageBox.Show("Dữ liệu chưa được nạp. Nhấn 'Hiển thị danh sách' hoặc load lại form.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                DataTable table = ds.Tables["tbl" + tableName];
                if (table == null)
                {
                    MessageBox.Show("Không tìm thấy bảng dữ liệu trong DataSet.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                DataRow row = table.NewRow();
                if (table.Columns.Contains("XB")) row["XB"] = txtMaXB.Text.Trim();
                else if (table.Columns.Contains("MaNXB")) row["MaNXB"] = txtMaXB.Text.Trim();
                if (table.Columns.Contains("TenXB")) row["TenXB"] = txtTenXB.Text.Trim();
                if (table.Columns.Contains("DiaChi")) row["DiaChi"] = txtDiaChi.Text.Trim();

                table.Rows.Add(row);
                MoKetNoi();
                int kq = adapter.Update(table);
                if (kq > 0)
                {
                    MessageBox.Show("Thêm dữ liệu thành công!");
                    hienThiDuLieu();
                    XoaDuLieuForm();
                }
                else
                {
                    MessageBox.Show("Thêm dữ liệu không thành công!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm dữ liệu:\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DongKetNoi();
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            try
            {
                if (sqlCon != null)
                {
                    sqlCon.Dispose();
                    sqlCon = null;
                }
            }
            catch {{ }}
        }
    }
}
