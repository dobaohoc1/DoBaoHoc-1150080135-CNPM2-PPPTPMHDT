namespace DoBaoHoc_1150080135_Bttuan9_Lab7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.split = new System.Windows.Forms.SplitContainer();
            this.dgvDanhSach = new System.Windows.Forms.DataGridView();
            this.topFlow = new System.Windows.Forms.FlowLayoutPanel();
            this.btnHienThi = new System.Windows.Forms.Button();
            this.grp = new System.Windows.Forms.GroupBox();
            this.tbl = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtMaXB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTenXB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.btnFlow = new System.Windows.Forms.FlowLayoutPanel();
            this.btnThemDL = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.split)).BeginInit();
            this.split.Panel1.SuspendLayout();
            this.split.Panel2.SuspendLayout();
            this.split.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSach)).BeginInit();
            this.topFlow.SuspendLayout();
            this.grp.SuspendLayout();
            this.tbl.SuspendLayout();
            this.btnFlow.SuspendLayout();
            this.SuspendLayout();
            // 
            // split
            // 
            this.split.Dock = System.Windows.Forms.DockStyle.Fill;
            this.split.Location = new System.Drawing.Point(0, 0);
            this.split.Name = "split";
            // 
            // split.Panel1
            // 
            this.split.Panel1.Controls.Add(this.dgvDanhSach);
            this.split.Panel1.Controls.Add(this.topFlow);
            // 
            // split.Panel2
            // 
            this.split.Panel2.Controls.Add(this.grp);
            this.split.Size = new System.Drawing.Size(800, 450);
            this.split.SplitterDistance = 450;
            this.split.TabIndex = 0;
            // 
            // dgvDanhSach
            // 
            this.dgvDanhSach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhSach.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDanhSach.Location = new System.Drawing.Point(0, 50);
            this.dgvDanhSach.Name = "dgvDanhSach";
            this.dgvDanhSach.RowHeadersWidth = 51;
            this.dgvDanhSach.Size = new System.Drawing.Size(450, 400);
            this.dgvDanhSach.TabIndex = 1;
            // 
            // topFlow
            // 
            this.topFlow.Controls.Add(this.btnHienThi);
            this.topFlow.Dock = System.Windows.Forms.DockStyle.Top;
            this.topFlow.Location = new System.Drawing.Point(0, 0);
            this.topFlow.Name = "topFlow";
            this.topFlow.Padding = new System.Windows.Forms.Padding(10);
            this.topFlow.Size = new System.Drawing.Size(450, 50);
            this.topFlow.TabIndex = 0;
            // 
            // btnHienThi
            // 
            this.btnHienThi.AutoSize = true;
            this.btnHienThi.Location = new System.Drawing.Point(13, 13);
            this.btnHienThi.Name = "btnHienThi";
            this.btnHienThi.Size = new System.Drawing.Size(120, 27);
            this.btnHienThi.TabIndex = 0;
            this.btnHienThi.Text = "Hiển thị danh sách";
            this.btnHienThi.UseVisualStyleBackColor = true;
            // 
            // grp
            // 
            this.grp.Controls.Add(this.tbl);
            this.grp.Controls.Add(this.btnFlow);
            this.grp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grp.Location = new System.Drawing.Point(0, 0);
            this.grp.Name = "grp";
            this.grp.Padding = new System.Windows.Forms.Padding(10);
            this.grp.Size = new System.Drawing.Size(346, 450);
            this.grp.TabIndex = 0;
            this.grp.TabStop = false;
            this.grp.Text = "Chỉnh sửa thông tin";
            // 
            // tbl
            // 
            this.tbl.ColumnCount = 2;
            this.tbl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35F));
            this.tbl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65F));
            this.tbl.Controls.Add(this.label1, 0, 0);
            this.tbl.Controls.Add(this.txtMaXB, 1, 0);
            this.tbl.Controls.Add(this.label2, 0, 1);
            this.tbl.Controls.Add(this.txtTenXB, 1, 1);
            this.tbl.Controls.Add(this.label3, 0, 2);
            this.tbl.Controls.Add(this.txtDiaChi, 1, 2);
            this.tbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.tbl.Location = new System.Drawing.Point(10, 23);
            this.tbl.Name = "tbl";
            this.tbl.RowCount = 3;
            this.tbl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tbl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tbl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tbl.Size = new System.Drawing.Size(326, 130);
            this.tbl.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã NXB:";
            // 
            // txtMaXB
            // 
            this.txtMaXB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMaXB.Location = new System.Drawing.Point(117, 11);
            this.txtMaXB.Name = "txtMaXB";
            this.txtMaXB.Size = new System.Drawing.Size(206, 20);
            this.txtMaXB.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Tên NXB:";
            // 
            // txtTenXB
            // 
            this.txtTenXB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTenXB.Location = new System.Drawing.Point(117, 54);
            this.txtTenXB.Name = "txtTenXB";
            this.txtTenXB.Size = new System.Drawing.Size(206, 20);
            this.txtTenXB.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Địa chỉ:";
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDiaChi.Location = new System.Drawing.Point(117, 98);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(206, 20);
            this.txtDiaChi.TabIndex = 5;
            // 
            // btnFlow
            // 
            this.btnFlow.Controls.Add(this.btnThemDL);
            this.btnFlow.Controls.Add(this.btnSua);
            this.btnFlow.Controls.Add(this.btnXoa);
            this.btnFlow.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnFlow.Location = new System.Drawing.Point(10, 380);
            this.btnFlow.Name = "btnFlow";
            this.btnFlow.Padding = new System.Windows.Forms.Padding(10);
            this.btnFlow.Size = new System.Drawing.Size(326, 60);
            this.btnFlow.TabIndex = 0;
            // 
            // btnThemDL
            // 
            this.btnThemDL.Location = new System.Drawing.Point(13, 13);
            this.btnThemDL.Name = "btnThemDL";
            this.btnThemDL.Size = new System.Drawing.Size(90, 30);
            this.btnThemDL.TabIndex = 0;
            this.btnThemDL.Text = "Thêm dữ liệu";
            this.btnThemDL.UseVisualStyleBackColor = true;
            // 
            // btnSua
            // 
            this.btnSua.Location = new System.Drawing.Point(109, 13);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(90, 30);
            this.btnSua.TabIndex = 1;
            this.btnSua.Text = "Chỉnh sửa";
            this.btnSua.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            this.btnXoa.Location = new System.Drawing.Point(205, 13);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(90, 30);
            this.btnXoa.TabIndex = 2;
            this.btnXoa.Text = "Xóa dữ liệu";
            this.btnXoa.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.split);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Form1";
            this.Text = "Quản lý Nhà Xuất Bản";
            this.split.Panel1.ResumeLayout(false);
            this.split.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.split)).EndInit();
            this.split.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSach)).EndInit();
            this.topFlow.ResumeLayout(false);
            this.topFlow.PerformLayout();
            this.grp.ResumeLayout(false);
            this.tbl.ResumeLayout(false);
            this.tbl.PerformLayout();
            this.btnFlow.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer split;
        private System.Windows.Forms.DataGridView dgvDanhSach;
        private System.Windows.Forms.FlowLayoutPanel topFlow;
        private System.Windows.Forms.Button btnHienThi;
        private System.Windows.Forms.GroupBox grp;
        private System.Windows.Forms.TableLayoutPanel tbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtMaXB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtTenXB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.FlowLayoutPanel btnFlow;
        private System.Windows.Forms.Button btnThemDL;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Label label4;
    }
}