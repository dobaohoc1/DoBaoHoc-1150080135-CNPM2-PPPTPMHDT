﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Reporting.WinForms;

namespace DoBaoHoc_1150080135_Bttuan9_Lab8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Administrator\Downloads\DoBaoHoc_1150080135_Bttuan9_Lab8\DoBaoHoc_1150080135_Bttuan9_Lab8\Database1.mdf;Integrated Security=True";

        // SqlConnection instance
        private SqlConnection sqlCon = null;

        // Open connection if needed
        private void OpenConnection()
        {
            if (sqlCon == null)
            {
                sqlCon = new SqlConnection(connectionString);
            }

            if (sqlCon.State == ConnectionState.Closed)
            {
                sqlCon.Open();
            }
        }

        private void CloseConnection()
        {
            if (sqlCon != null && sqlCon.State != ConnectionState.Closed)
            {
                sqlCon.Close();
                sqlCon.Dispose();
                sqlCon = null;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                OpenConnection();

                string query = "SELECT * FROM SinhVien";

                using (SqlDataAdapter adapter = new SqlDataAdapter(query, sqlCon))
                {
                    DataTable dt = new DataTable("SinhVien");
                    adapter.Fill(dt);

                    // Make sure the reportviewer has no leftover data sources
                    this.reportViewer1.LocalReport.DataSources.Clear();

                    // Set the embedded report path. Adjust the namespace if your project's default namespace is different.
                    this.reportViewer1.LocalReport.ReportEmbeddedResource = "DoBaoHoc_1150080135_Bttuan9_Lab8.rptSinhVien.rdlc";

                    // The name must match the DataSet name defined inside the RDLC report (here it's "DataSet1").
                    ReportDataSource rds = new ReportDataSource("DataSet1", dt);
                    this.reportViewer1.LocalReport.DataSources.Add(rds);

                    this.reportViewer1.RefreshReport();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu báo cáo: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                CloseConnection();
            }
        }
    }
}
